package com.Simplelearn.SpringFile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
